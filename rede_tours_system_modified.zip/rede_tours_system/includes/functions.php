<?php

function updateBalance($conn){

    // TOTAL INCOME
    $income = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT 
    SUM(CASE WHEN currency='USD' THEN amount ELSE 0 END) as usd,
    SUM(CASE WHEN currency='TZS' THEN amount ELSE 0 END) as tzs
    FROM income
    "));

    // TOTAL EXPENSES
    $expense = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT 
    SUM(CASE WHEN currency='USD' THEN amount ELSE 0 END) as usd,
    SUM(CASE WHEN currency='TZS' THEN amount ELSE 0 END) as tzs
    FROM expenditures
    "));

    // BALANCE CALCULATION
    $balance_usd = $income['usd'] - $expense['usd'];
    $balance_tzs = $income['tzs'] - $expense['tzs'];

    // UPDATE DATABASE
    mysqli_query($conn,
    "UPDATE currency_balances 
    SET balance = $balance_usd 
    WHERE currency='USD'");

    mysqli_query($conn,
    "UPDATE currency_balances 
    SET balance = $balance_tzs 
    WHERE currency='TZS'");
}

function checkOverdueDebts($conn){

    mysqli_query($conn,
    "UPDATE debts 
     SET status='overdue'
     WHERE status='unpaid' 
     AND due_date < CURDATE()"
    );
}

?>