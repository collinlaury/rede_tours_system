<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "rede_tours_db";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

date_default_timezone_set('Africa/Dar_es_Salaam');

?>